package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoanAmountPage {

	WebDriver driver;
	By id=By.id("loanAmount");
	//By continueButton=By.tagName("button");
	By continueButton=By.cssSelector("button[type='submit']");
	public LoanAmountPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public void setLoanAmount(String strLoanAmt){

        driver.findElement(id).sendKeys(strLoanAmt);

    }
	
	public void enterLoanAmount(String strLoanAmt){
	
		 //Fill Loan Amount

        this.setLoanAmount(strLoanAmt);
        driver.findElement(continueButton).click();
		
	
	}
	
}
