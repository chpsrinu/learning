package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoanLookingPage {

	WebDriver driver;
	By homeImprovement=By.className("_1sav3lyK");
	By clickContinue=By.xpath("//button[@type='submit']");
	public LoanLookingPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	
	public void clickHomeImprovement()
	{
		driver.findElement(homeImprovement).click();
		
	}
	public void clickContinueButton()
	{
		driver.findElement(clickContinue).click();
		
	}
	
	public void loanlookingMethos(){
		
		clickHomeImprovement();
		clickContinueButton();
	}
	
	
}
