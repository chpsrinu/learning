package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EducationLevelPage {

	WebDriver driver;
	By bachelorEducation=By.xpath("//span[@class='_1sav3lyK']");
	public EducationLevelPage(WebDriver driver)
	{
	 this.driver=driver;
	}
	
	
	public void clickBachelorEducation() {
		
		driver.findElement(bachelorEducation).click();
	}
	
	
}
