package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EmploymtStatusPage {

	WebDriver driver;
	By employmentStatus=By.cssSelector("//[class='_1sav3lyK']");
	public EmploymtStatusPage(WebDriver driver)
	{
		this.driver=driver;
	}
	public void clickEmploymtStatus()
	{
		driver.findElement(employmentStatus).click();
	}
	
}
