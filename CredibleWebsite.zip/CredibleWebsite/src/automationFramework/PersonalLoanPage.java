package automationFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PersonalLoanPage {
	
	WebDriver driver;
	By getStarted=By.xpath("//a[@href='/personal-loans/borrower']");
	//By getStarted=By.linkText();
	By id=By.id("loanAmount");
	By continueButton=By.tagName("button");
	public PersonalLoanPage(WebDriver driver)
	{
		this.driver=driver;
	}
	public void clickPersonalLoan(){

        driver.findElement(getStarted).click();

}
	public void setLoanAmount(String strLoanAmt){

        driver.findElement(id).sendKeys(strLoanAmt);

    }
	
	public void enterLoanAmount(String strLoanAmt){
	
		 //Fill Loan Amount

        this.setLoanAmount(strLoanAmt);
		
	
	}
	public void clickContinue(){

        driver.findElement(continueButton).click();

}
	
	}


