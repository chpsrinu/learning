package automationFramework;

import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginPageTestcase {
	public static void main(String[] args)
	{
	WebDriver driver;
	CredibleLogInPage objLogin;
	PersonalLoanPage objPersonalLoan;
	LoanAmountPage objLoanAmount;
	LoanLookingPage objLoanLooking;
	EducationLevelPage objEducationLevel; 
	EmploymtStatusPage objEmplymntStatus;
	AnnualIncomePage objAnnualIncome;
	//@BeforeTest
	

    //public void setup(){

		System.setProperty("webdriver.chrome.driver","C:\\Swathi\\ChromeDrivers\\chromedriver.exe");
		
		By loginButton = By.linkText("Log In");
		
		System.out.println(System.getProperty("webdriver.chrome.driver"));
		ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-popup-blocking"); 
        
		
		driver = new ChromeDriver(options);

        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.get("http://www.credible.com");
        driver.findElement(loginButton).click();

    //}

	/**

     * This test case will login in http://demo.guru99.com/V4/

     * Verify login page title as guru99 bank

     * Login to application

     * Verify the home page using Dashboard message

     */
	//@Test(priority=0)

    //public void test_Home_Page_Appear_Correct(){

        //Create Login Page object

    objLogin = new CredibleLogInPage(driver);
    objPersonalLoan=new PersonalLoanPage(driver);
    objLoanAmount=new LoanAmountPage(driver);
    objLoanLooking=new LoanLookingPage(driver);
//    objEducationLevel=new EducationLevelPage(driver);
//    objEmplymntStatus=new EmploymtStatusPage(driver);
//    objAnnualIncome=new AnnualIncomePage(driver);

    //Verify login page title

    //String loginPageTitle = objLogin.getLoginTitle();

    //Assert.assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));

    //login to application
    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    objLogin.loginToCredible("Swathi9191231@credible.com", "Passw0rd");
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    objPersonalLoan.clickPersonalLoan();
   objLoanAmount.enterLoanAmount("2000");
    objLoanLooking.loanlookingMethos();
//    objEducationLevel.clickBachelorEducation();
//    objEmplymntStatus.clickEmploymtStatus();
//    objAnnualIncome.setAnnualIcome("20000");
    
    

}
}
//}
